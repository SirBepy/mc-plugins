# This function opens the cookbook.

function rmf:give_item/cookbook {player:"@s",count:1}
clear @s[gamemode=creative] *[custom_data~{item_id:"rmf:cookbook"}] 1
dialog show @s rmf:cookbook_menu
advancement revoke @s only rmf:bg/open_cookbook