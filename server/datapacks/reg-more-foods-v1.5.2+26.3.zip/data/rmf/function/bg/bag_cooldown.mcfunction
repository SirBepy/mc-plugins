# This function runs on a schedule as long as the player has the "bag_popcorn" advancement (the player is trying to put something in a popcorn bag).
# The schedule runs every 10 ticks (0.5 seconds) and is designed to act as a cooldown for the Popcorn Bag to prevent players from using it too fast by removing the advancement.
# This cooldown can be altered by just changing the interval the schedule is run in the "rmf:bg/bag_popcorn" function--though, it's recommended that you leave the setting as it is so you don't accidentally bag all the popped corn in your offhand at once.
#
advancement revoke @a[advancements={rmf:bg/bag_popcorn=true}] only rmf:bg/bag_popcorn