# This function returns the bowl used to craft Spaghetti.
# It may also be reused for any other recipe which requires returning a bowl. Saves time!
give @s minecraft:bowl
advancement revoke @s only rmf:bg/bowl_refunder