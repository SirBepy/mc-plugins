# This function perpetuates the cycle of unlimited bacon by giving the player bacon their bacon if they eat it.
# UPDATE: what the fuck did i write. "giving the player bacon their bacon if they eat it" what on earth did i mean by that

function rmf:give_item/unlimited_bacon {"player":"@s","count":1}
advancement revoke @s only rmf:bg/eat_unlimited_bacon