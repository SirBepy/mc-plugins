# Activates when the appropriate Shaker Cup advancement is triggered.
# Gives the player a new Shaker Cup with the contents of their recipe, and removes the triggering advancement (to be reactivated later)
function rmf:give_item/shaker_cup_filled {"player":"@s","count":1,"contents":"mango_smoothie"}
advancement revoke @s only rmf:bg/shaker_cup/mango_smoothie_craft