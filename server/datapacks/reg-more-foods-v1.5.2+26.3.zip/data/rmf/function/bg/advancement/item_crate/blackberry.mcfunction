# This function works in this order:
# - Revoke the advancement for the crate, so it can be reopened
# - Check if the config for needing a Crowbar on an Item Crate is enabled, and if it is, check if the player has one
# - If the player needs one but lacks one, give them back their crate and yell at them. Then, stop the function
# - If everything passes, give them their item and play a sound

advancement revoke @s only rmf:bg/item_crate/blackberry
execute if score rmf.config rmf.itemCratesRequireCrowbar matches 1.. unless items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:crowbar"}] run function rmf:give_item/item_crate_blackberry {"player":"@s","count":1}
execute if score rmf.config rmf.itemCratesRequireCrowbar matches 1.. unless items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:crowbar"}] run return run title @s actionbar {"translate":"chat.rmf.item_crate.no_crowbar","color":"red"}
function rmf:give_item/blackberry {"player":"@s","count":9}
execute at @s run playsound rmf:item.item_crate.open player