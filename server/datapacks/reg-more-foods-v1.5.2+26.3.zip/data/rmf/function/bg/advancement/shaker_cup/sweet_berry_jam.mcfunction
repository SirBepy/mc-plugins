# Activates when the appropriate Shaker Cup advancement is triggered.
# Gives the player the recipe they crafted, removes the appropriate container, and returns the shaker cup depending on if the recipe has multiple outputs. Give the player an advancement, if any.
# Also, return the shaker cup to the player after the recipe is fully done
function rmf:give_item/sweet_berry_jam {"player":"@s","count":1}
clear @s minecraft:bowl 1
clear @s *[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"sweet_berry_jam"}] 1
advancement grant @s only rmf:not_jammed
function rmf:give_item/shaker_cup {"player":"@s","count":1}