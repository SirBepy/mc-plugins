# Activates when the appropriate Shaker Cup advancement is triggered.
# Gives the player the recipe they crafted, removes the appropriate container, and returns the shaker cup depending on if the recipe has multiple outputs. Give the player an advancement, if any
# Also, return the shaker cup to the player after the recipe is fully done
function rmf:give_item/coffee {"player":"@s","count":1}
clear @s minecraft:glass_bottle 1
clear @s *[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"coffee"}] 1
advancement grant @s only rmf:shaken_not_stirred
function rmf:give_item/shaker_cup {"player":"@s","count":1}