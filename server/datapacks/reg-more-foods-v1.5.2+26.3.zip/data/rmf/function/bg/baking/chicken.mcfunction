# This function is the "baking" recipe. If conditions are met when baking items, the following commands will be run.
# Each command is designed only for non-creative players--if a player is in creative mode, the ingredient will not be consumed.
#
clear @s[gamemode=!creative] chicken 1
give @s cooked_chicken
# Remember to reset their cooking score so this doesn't run forever!
scoreboard players set @s rmf.bakingProgress 0
execute as @s run summon minecraft:experience_orb ~ ~ ~ {Value:1}