# This function is identical to the one used for tracking blocks that can heat the baking pan.
# If addon creators want to add their own heat sources, they first need to add to the appropriate block tags for tracking it, then add to the list here.

# Lower the player's rmf.bakingProgress score if they AREN'T trying to cook anything
execute as @a[scores={rmf.bakingProgress=1..}] at @s unless block ^ ^1 ^ #rmf:can_heat_baking_pan run scoreboard players set @s rmf.bakingProgress 0
# Furnace
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ furnace[lit=true] run scoreboard players add @s rmf.bakingProgress 1
# Smoker
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ smoker[lit=true] run scoreboard players add @s rmf.bakingProgress 1
# Soul Campfire
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ soul_campfire[lit=true] run scoreboard players add @s rmf.bakingProgress 1
# Soul Fire
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ soul_fire run scoreboard players add @s rmf.bakingProgress 1
# Magma Block
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ magma_block run scoreboard players add @s rmf.bakingProgress 2
# Blast Furnace
execute as @a[predicate=rmf:baking_pan_cookable,advancements={rmf:bg/baking_item=true},scores={rmf.bakingProgress=20..99}] at @s if block ^ ^1 ^ blast_furnace[lit=true] run scoreboard players add @s rmf.bakingProgress 2