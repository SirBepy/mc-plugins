# This function's job is setting up the Baking Pan to prepare to cook something.
# It works identically to the Frying Pan's functions, except they each have their own score system because they couldn't play nice when sharing one

# If the player is standing in front of a block that can heat the baking pan, start warming up the pan to cook
execute at @s[scores={rmf.bakingProgress=..19}] if block ^ ^1 ^ #rmf:heats_baking_pan_if_lit[lit=true] run scoreboard players add @s rmf.bakingProgress 2
execute at @s[scores={rmf.bakingProgress=..19}] if block ^ ^1 ^ #rmf:heats_baking_pan_always run scoreboard players add @s rmf.bakingProgress 2

# If the player starts cooking, play a sound to indicate the baking pan is doing something so they aren't confused (but make sure they're holding something bakeable so it doesn't play for no reason)
execute as @s[predicate=rmf:baking_pan_cookable,scores={rmf.bakingProgress=2}] at @s run playsound rmf:item.baking_pan.bake player @s ~ ~ ~ .5

# If the player is trying to bake something but isn't standing in front of something that can heat the Baking Pan, yell at them until they do
execute at @s unless block ^ ^1 ^ #rmf:can_heat_baking_pan run title @s actionbar {"translate":"chat.rmf.frying_pan.no_heat","color":"red"}

# If the player is trying to bake something but isn't holding something they can cook in the Baking Pan, yell at them until they do
execute unless predicate rmf:baking_pan_cookable run title @s actionbar {"translate":"chat.rmf.frying_pan.no_item","color":"red"}

# If the player is standing in front of something that can heat the Frying Pan, but not the Baking Pan, yell at them about it
execute at @s if block ^ ^1 ^ #rmf:can_heat_frying_pan unless block ^ ^1 ^ #rmf:can_heat_baking_pan run title @s actionbar {"translate":"chat.rmf.baking_pan.low_heat","color":"red"}

# If the player has reached max bakingProgress, send them to the baking recipes function to decide their fate (what item gets cooked). Then, schedule a checkfor function to make sure they're still trying to cook
execute if score @s rmf.bakingProgress matches 100.. run function rmf:bg/baking/_recipes
schedule function rmf:bg/baking/checkfor 2t