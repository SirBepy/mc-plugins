# This function tracks what foods you can bake in the baking pan. Works exactly like the Frying Pan.

# -- VANILLA ITEMS --
# Items whoses ingredients are vanilla, even if the result isn't
# Cooked Beef
execute if items entity @s weapon.offhand beef run return run function rmf:bg/baking/beef
# Cooked Porkchop
execute if items entity @s weapon.offhand porkchop run return run function rmf:bg/baking/porkchop
# Cooked Mutton
execute if items entity @s weapon.offhand mutton run return run function rmf:bg/baking/mutton
# Cooked Rabbit
execute if items entity @s weapon.offhand rabbit run return run function rmf:bg/baking/rabbit
# Cooked Chicken
execute if items entity @s weapon.offhand chicken run return run function rmf:bg/baking/chicken
# Cooked Cod
execute if items entity @s weapon.offhand cod run return run function rmf:bg/baking/cod
# Cooked Salmon
execute if items entity @s weapon.offhand salmon run return run function rmf:bg/baking/salmon
execute if items entity @s weapon.offhand blue_egg run return run function rmf:bg/baking/blue_egg
# Leather
execute if items entity @s weapon.offhand rotten_flesh run return run function rmf:bg/baking/rotten_flesh
# Roasted Carrot
execute if items entity @s weapon.offhand carrot run return run function rmf:bg/baking/carrot
# Honeycomb Candy
execute if items entity @s weapon.offhand honeycomb run return run function rmf:bg/baking/honeycomb
# Baked Potato
execute if items entity @s weapon.offhand potato run return run function rmf:bg/baking/potato

# -- DATAPACK ITEMS --
# Items whoses ingredients aren't vanilla, even if their results are
# Popped Corn
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:popcorn_seeds"}] run return run function rmf:bg/baking/popcorn_seeds
# Cooked Ham
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:ham"}] run return run function rmf:bg/baking/ham
# Cooked Bacon
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:bacon"}] run return run function rmf:bg/baking/bacon
# Cooked Chicken Wing
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:chicken_wing"}] run return run function rmf:bg/baking/chicken_wing
# Bread (from Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:dough"}] run return run function rmf:bg/baking/dough
# Baguette (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:baguette"]}] run return run function rmf:bg/baking/dough_baguette
# Pretzel (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:pretzel"]}] run return run function rmf:bg/baking/dough_pretzel
# Croissant (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:croissant"]}] run return run function rmf:bg/baking/dough_croissant
# Plain Muffin (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:muffin"]}] run return run function rmf:bg/baking/dough_muffin
# Plain Donut (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:nut"]}] run return run function rmf:bg/baking/dough_nut
# Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:cookie"]}] run return run function rmf:bg/baking/dough_cookie
# Cocoa Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:cocoa_cookie"]}] run return run function rmf:bg/baking/dough_cocoa_cookie
# Honey Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:honey_cookie"]}] run return run function rmf:bg/baking/dough_honey_cookie
# Sweet Berry Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:berry_cookie"]}] run return run function rmf:bg/baking/dough_berry_cookie
# Glow Berry Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:glow_berry_cookie"]}] run return run function rmf:bg/baking/dough_glow_berry_cookie
# Dragon Fruit Pie
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:dragon_pie_mix"}] run return run function rmf:bg/baking/dragon_pie_mix
# Baked Beans
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:unbaked_beans"}] run return run function rmf:bg/baking/unbaked_beans
# Fruitcake
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:unbaked_fruitcake"}] run return run function rmf:bg/baking/unbaked_fruitcake
# Lemon Pie
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:lemon_pie_mix"}] run return run function rmf:bg/baking/lemon_pie_mix
# Banana Bread
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:banana_dough"}] run return run function rmf:bg/baking/banana_dough

# If for some horrid reason the player is able to run this function WITHOUT passing any of the entries here, just reset their fryingProgress and hope this works itself out
scoreboard players set @s rmf.fryingProgress 0