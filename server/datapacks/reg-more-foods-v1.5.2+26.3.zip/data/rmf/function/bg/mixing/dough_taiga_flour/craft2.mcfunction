# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s *[minecraft:custom_data~{item_id:"rmf:water_barrel"}] 1
function rmf:give_item/dough {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound rmf:item.mixing_bowl.use
advancement grant @s[advancements={rmf:dough=false}] only rmf:dough