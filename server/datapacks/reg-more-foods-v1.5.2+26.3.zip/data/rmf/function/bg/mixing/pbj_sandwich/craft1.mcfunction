# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s bread 2
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:bread"}},{type:"minecraft:set_lore",lore:[{"translate":"item.rmf.shaker_cup.contents","color":"white","italic":false},{"translate":"item.rmf.mixing_bowl.contents_bread","color":"aqua","italic":false}],"mode":"insert"}]
execute at @s run playsound minecraft:item.bundle.insert