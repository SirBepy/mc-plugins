# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s honey_bottle 1
give @s glass_bottle 1
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:peanut_butter3"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.shaker_cup.contents_honey",color:"aqua",italic:false}],mode:"insert",offset:3}]
execute at @s run playsound minecraft:item.bundle.insert