# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s sugar 2
function rmf:give_item/unbaked_fruitcake {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound rmf:item.mixing_bowl.use