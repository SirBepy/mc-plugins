# This file uses a mixture of the Juicer and the Shaker Cup's systems to create items using the Mixing Bowl. My previous method had too many holes (literally) and was annoying to work around. This is easier, despite how it looks.
# If you read the other files like this one, you'll know how to add your own entries. It's not too complicated, I know you'll be able to do it.

# Run this function on a cooldown.
schedule function rmf:bg/item_cooldown 10t replace

# Check for an empty hand. If offhand is empty when Mixing Bowl is used, and player is crouching, empty its contents if something is in it.
execute as @s if predicate rmf:empty_offhand if predicate rmf:is_crouching unless items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl"},minecraft:custom_data={"rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/empty


### Dough Crafting (Wheat Flour) ###

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:wheat_flour"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/dough_wheat_flour/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:water_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:flour"}] run return run function rmf:bg/mixing/dough_wheat_flour/craft2

### Dough Crafting (Taiga Flour) ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:taiga_flour"},minecraft:count={max:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:taiga_flour"},minecraft:count={min:3}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/dough_taiga_flour/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:water_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:dough"}] run return run function rmf:bg/mixing/dough_taiga_flour/craft2


### Dragon Fruit Pie Crafting ###

# Step 1
# If the player isn't holding at least 3 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:dragon_fruit"},minecraft:count={max:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 3, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:dragon_fruit"},minecraft:count={min:3}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/dragon_fruit_pie/craft1

# Step 2
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand sugar[minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:dragon_fruit_pie"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand sugar[count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:dragon_fruit_pie"}] run return run function rmf:bg/mixing/dragon_fruit_pie/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:milk_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:dragon_fruit_pie2"}] run return run function rmf:bg/mixing/dragon_fruit_pie/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:pie_crust"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:dragon_fruit_pie3"}] run return run function rmf:bg/mixing/dragon_fruit_pie/craft4

### Baked Beans Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:taiga_beans"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:taiga_beans"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/baked_beans/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:seasoning"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:baked_beans"}] run return run function rmf:bg/mixing/baked_beans/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand mushroom_stew if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:baked_beans2"}] run return run function rmf:bg/mixing/baked_beans/craft3

### Fruitcake Crafting ###

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:pale_apple"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/fruitcake/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peach"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:fruitcake"}] run return run function rmf:bg/mixing/fruitcake/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:orange"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:fruitcake2"}] run return run function rmf:bg/mixing/fruitcake/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:dough"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:fruitcake3"}] run return run function rmf:bg/mixing/fruitcake/craft4

# Step 5
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand sugar[minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:fruitcake4"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand sugar[minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:fruitcake4"}] run return run function rmf:bg/mixing/fruitcake/craft5

### Jam Crafting ###
# Making Jams is a little different than the other items on this list, as all jams are made in the same way but with different end ingredients. If I decide to add more Jams in the future they will follow this recipe structure.
# It's also not brought up anywhere else, but due to some recipes (like jams and lemon pie) needing the same starting item, their rmf_mixingBowlRecipe string is instead the name of the ingredient rather than the recipe they make

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:lemon_juice"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/jam/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand sugar if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:lemon_juice"}] run return run function rmf:bg/mixing/jam/craft2

### Sweet Berry Jam Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:sweet_berry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:jam"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}

# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:sweet_berry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:jam"}] run return run function rmf:bg/mixing/sweet_berry_jam/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand bowl if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:sweet_berry_jam"}] run return run function rmf:bg/mixing/sweet_berry_jam/craft2

### Glow Berry Jam Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:glow_berry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:jam"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}

# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:glow_berry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:jam"}] run return run function rmf:bg/mixing/glow_berry_jam/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand bowl if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:glow_berry_jam"}] run return run function rmf:bg/mixing/glow_berry_jam/craft2

### Lemon Pie Crafting ###

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:lemon_juice"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/lemon_pie/craft

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:milk_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:lemon_juice"}] run return run function rmf:bg/mixing/lemon_pie/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand #minecraft:eggs if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:lemon_pie"}] run return run function rmf:bg/mixing/lemon_pie/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:pie_crust"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:lemon_pie2"}] run return run function rmf:bg/mixing/lemon_pie/craft4

### Peanut Butter Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peanut"},minecraft:count={max:7}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peanut"},minecraft:count={min:8}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/peanut_butter/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:salt"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:peanut_butter"}] run return run function rmf:bg/mixing/peanut_butter/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand honey_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:peanut_butter2"}] run return run function rmf:bg/mixing/peanut_butter/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:peanut_butter3"}] run return run function rmf:bg/mixing/peanut_butter/craft4

### PB&J Sandwich Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand bread[minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand bread[minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/pbj_sandwich/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:sweet_berry_jam"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:bread"}] run return run function rmf:bg/mixing/pbj_sandwich/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peanut_butter"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:pbj_sandwich"}] run return run function rmf:bg/mixing/pbj_sandwich/craft3

### Glowing PB&J Sandwich Crafting ###
# The first step of making a Glowing PBJ is the same as a regular PBJ (adding bread), so we can just reuse that for the step 1 of both recipes like we do for lemons with jam and pie

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:glow_berry_jam"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:bread"}] run return run function rmf:bg/mixing/glow_pbj_sandwich/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peanut_butter"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:glow_pbj_sandwich"}] run return run function rmf:bg/mixing/glow_pbj_sandwich/craft2

### Banana Dough Crafting ###

# Step 1
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:banana_mash"},minecraft:count={max:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:banana_mash"},minecraft:count={min:3}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/banana_dough/craft1

# Step 2
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand #minecraft:eggs[minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:banana_dough"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand #minecraft:eggs[minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:banana_dough"}] run return run function rmf:bg/mixing/banana_dough/craft2

# Step 3
# For this step, since we can accept either wheat flour or taiga flour, we can check for both accordingly
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{"rmf":"is_flour"}]},minecraft:count={max:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:banana_dough2"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{"rmf":"is_flour"}]},minecraft:count={min:3}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:banana_dough2"}] run return run function rmf:bg/mixing/banana_dough/craft3

### Berry Medley Crafting ###
# Since this recipe can use any 4 berries, we can just copy the first step 4 times and hope this doesn't back fire horribly later

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{rmf:"is_berry"}]}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/berry_bowl/craft1

# Step 2
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{rmf:"is_berry"}]}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:berry_bowl"}] run return run function rmf:bg/mixing/berry_bowl/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{rmf:"is_berry"}]}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:berry_bowl2"}] run return run function rmf:bg/mixing/berry_bowl/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{rmf:"is_berry"}]}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:berry_bowl3"}] run return run function rmf:bg/mixing/berry_bowl/craft4

# Step 5
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand bowl if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:berry_bowl4"}] run return run function rmf:bg/mixing/berry_bowl/craft5

### Pancake Mix Crafting ###

# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand sugar if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":""}] run return run function rmf:bg/mixing/pancake_mix/craft1

# Step 2
# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{"rmf":"is_flour"}]},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:sugar"}] run return run title @s actionbar {"translate": "chat.rmf.mixing_bowl.need_more_items","color":"red"}
# If the player has at least 2, put them in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_tags":[{"rmf":"is_flour"}]},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:sugar"}] run return run function rmf:bg/mixing/pancake_mix/craft2

# Step 3
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:milk_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:pancake_mix"}] run return run function rmf:bg/mixing/pancake_mix/craft3

# Step 4
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand honey_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:pancake_mix2"}] run return run function rmf:bg/mixing/pancake_mix/craft4

### Waffle Batter Crafting ###
# Since the recipe is nearly the same, we only check for the different ingredient
# Step 1
# If the player has the right item, put it in the bowl
execute if items entity @s weapon.offhand #minecraft:eggs if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:mixing_bowl","rmf_mixingBowlRecipe":"rmf:pancake_mix2"}] run return run function rmf:bg/mixing/waffle_batter/craft1


# If none of the above entries matched, the player isn't able to do any of the steps. Thus, this function continues to this last command
title @s actionbar {"translate":"chat.rmf.use_item.empty_hand","color":"red"}