# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound and grants an advancement. In the case of this file, it's context appropriate and grants 2 advancements.

clear @s *[custom_data~{"item_id":"rmf:peanut_butter"}] 1
give @s glass_bottle
function rmf:give_item/glow_pbj_sandwich {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound block.honey_block.break
advancement grant @s[advancements={rmf:the_iconic_assembly=false}] only rmf:the_iconic_assembly crafted glowing pbj sandwich
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food glowing pbj sandwich