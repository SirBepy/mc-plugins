# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s #minecraft:eggs 2
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:banana_dough2"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.mixing_bowl.contents_egg",color:"aqua",italic:false}],mode:"insert",offset:2}]
execute at @s run playsound minecraft:item.bundle.insert