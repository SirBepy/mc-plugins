# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things. In the context of this file, it checks for one of 2 valid ingredients and removes the appropriate one(s).
# Also plays a sound.

execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:wheat_flour"}] run clear @s *[custom_data~{"item_id":"rmf:wheat_flour"}] 3
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:taiga_flour"}] run clear @s *[custom_data~{"item_id":"rmf:taiga_flour"}] 3
function rmf:give_item/banana_dough {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound rmf:item.mixing_bowl.use