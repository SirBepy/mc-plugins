# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s #minecraft:eggs 1
function rmf:give_item/waffle_batter {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound rmf:item.mixing_bowl.use