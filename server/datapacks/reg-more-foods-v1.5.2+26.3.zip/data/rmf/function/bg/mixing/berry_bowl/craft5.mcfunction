# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Since all the player is doing is putting berries in a bowl, no sound is played when the bowl is added. But they do get advancement progress!

clear @s bowl 1
function rmf:give_item/berry_bowl {"player":"@s","count":1}
function rmf:bg/mixing/empty
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food berry medley