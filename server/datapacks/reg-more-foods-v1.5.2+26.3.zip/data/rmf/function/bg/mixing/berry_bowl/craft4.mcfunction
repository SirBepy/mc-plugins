# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things. Due to how unique this recipe is, we check each time if the player is holding any berry type and remove that specific one from the inventory.
# Also plays a sound.

execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:strawberry"}] run clear @s *[custom_data~{"item_id":"rmf:strawberry"}] 1
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:raspberry"}] run clear @s *[custom_data~{"item_id":"rmf:raspberry"}] 1
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:blueberry"}] run clear @s *[custom_data~{"item_id":"rmf:blueberry"}] 1
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:blackberry"}] run clear @s *[custom_data~{"item_id":"rmf:blackberry"}] 1
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:pale_berries"}] run clear @s *[custom_data~{"item_id":"rmf:pale_berries"}] 1
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:berry_bowl4"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.mixing_bowl.contents_berries",color:"aqua",italic:false}],mode:"insert",offset:4}]
execute at @s run playsound minecraft:item.bundle.insert