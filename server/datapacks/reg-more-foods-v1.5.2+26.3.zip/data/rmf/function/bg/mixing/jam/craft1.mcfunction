# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s *[custom_data~{"item_id":"rmf:lemon_juice"}] 1
give @s glass_bottle
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:lemon_juice"}},{type:"minecraft:set_lore",lore:[{"translate":"item.rmf.shaker_cup.contents","color":"white","italic":false},{"translate":"item.rmf.mixing_bowl.contents_lemon_juice","color":"aqua","italic":false}],"mode":"insert"}]
execute at @s run playsound minecraft:item.bundle.insert