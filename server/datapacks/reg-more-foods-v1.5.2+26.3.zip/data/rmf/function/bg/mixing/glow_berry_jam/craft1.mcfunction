# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s *[custom_data~{"item_id":"rmf:glow_berry_mash"}] 2
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:glow_berry_jam"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.mixing_bowl.contents_glow_berry_mash",color:"aqua",italic:false}],mode:"insert",offset:3}]
execute at @s run playsound minecraft:item.bundle.insert