# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:wheat_flour"}] run clear @s *[custom_data~{"item_id":"rmf:wheat_flour"}] 2
execute if items entity @s weapon.offhand *[custom_data~{item_id:"rmf:taiga_flour"}] run clear @s *[custom_data~{"item_id":"rmf:taiga_flour"}] 2
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:pancake_mix"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.mixing_bowl.contents_flour",color:"aqua",italic:false}],mode:"insert",offset:2}]
execute at @s run playsound minecraft:item.bundle.insert