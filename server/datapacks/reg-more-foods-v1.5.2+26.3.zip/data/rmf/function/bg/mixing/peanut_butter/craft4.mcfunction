# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound and grants an advancement.

clear @s glass_bottle 1
function rmf:give_item/peanut_butter {"player":"@s","count":1}
function rmf:bg/mixing/empty
execute at @s run playsound rmf:item.mixing_bowl.use
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food peanut butter