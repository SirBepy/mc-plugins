# A step in a crafting recipe.
# Typically removes an ingredient, then manually updates the mixing bowl with necessary data to continue making things.
# Also plays a sound.

clear @s *[custom_data~{"item_id":"rmf:seasoning"}] 1
item modify entity @s weapon.mainhand [{type:"minecraft:set_custom_data",tag:{rmf_mixingBowlRecipe:"rmf:baked_beans2"}},{type:"minecraft:set_lore",lore:[{translate:"item.rmf.mixing_bowl.contents_seasoning",color:"aqua",italic:false}],mode:"insert",offset:2}]
execute at @s run playsound minecraft:item.bundle.insert