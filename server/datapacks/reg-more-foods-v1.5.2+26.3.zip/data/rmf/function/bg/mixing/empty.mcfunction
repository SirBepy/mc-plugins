# This function triggers if the mixing bowl is used with an empty offhand while crouching.
# When this function is called, it replaces the player's mixing bowl with a fresh one, clearing everything inside the old one.

# Clear the player's mainhand completely, then just give them a new shaker
item replace entity @s weapon.mainhand with air
function rmf:give_item/mixing_bowl {"player":"@s","count":1}
# Play a sound so the player knows the bowl was emptied correctly
execute at @s run playsound rmf:item.mixing_bowl.empty