# Checks if the player breaks a cactus with their bare hands, and damages them if they do
# If they're holding a Cactus when they do it, don't hurt them and instead give them an advancement
# Then, reset the "rmf:mined_cactus" score so can check again later
execute if predicate rmf:empty_mainhand run damage @s 1 minecraft:cactus
execute if predicate rmf:empty_mainhand run advancement grant @s only rmf:yeouch
execute if items entity @s weapon.mainhand cactus run advancement grant @s only rmf:higher_brain
scoreboard players set @s rmf.mined_cactus 0