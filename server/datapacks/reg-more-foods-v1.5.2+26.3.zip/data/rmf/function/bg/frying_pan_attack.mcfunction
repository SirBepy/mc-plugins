# Plays a silly *DOING!* sound effect when a player attacks a mob with a Frying Pan, then remove the advancement so they can do it again
# Occasionally plays the TF2 Pan sound effect (at a much quieter volume!)
execute at @s run playsound rmf:item.frying_pan.hit player @s ~ ~ ~
advancement revoke @s only rmf:bg/frying_pan_attack