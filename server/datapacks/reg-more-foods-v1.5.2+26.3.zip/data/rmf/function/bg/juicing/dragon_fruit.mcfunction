# Controls the recipe for the name of the file. Also grants the "crafted_food" advancement if the player somehow hasn't gotten it yet.
# Remove the ingredient used, remove the glass bottle in the player's inventory, then give the player the custom item.
# Oh yeah, also play a noise for the player squeezing the item.

clear @s *[custom_data~{item_id:"rmf:dragon_fruit"}] 2
clear @s glass_bottle 1
function rmf:give_item/dragon_fruit_juice {"player":"@s","count":1}
playsound rmf:item.juicer.squeeze player @a ~ ~ ~
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food dragon fruit juice