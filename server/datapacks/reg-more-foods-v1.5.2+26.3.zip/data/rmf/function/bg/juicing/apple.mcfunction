# Controls the recipe for the name of the file. Also grants the "crafted_food" advancement if the player somehow hasn't gotten it yet.
# Remove the ingredient used, remove the glass bottle in the player's inventory, then give the player the custom item.
# Oh yeah, also play a noise for the player squeezing the item.
#
# The apple recipe function needs a specific component match, as there are other foods that use the apple's namespace, thus making it able to accidentally use those items instead of the apple in the player's offhand
clear @s apple[!custom_data] 2
clear @s glass_bottle 1
function rmf:give_item/apple_juice {"player":"@s","count":1}
playsound rmf:item.juicer.squeeze player @a ~ ~ ~
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food apple juice