# This function grabs data from the rmf:get_data config function, then displays it for the player.

$tellraw @s "\n\n\n\n\nGrabbing component data:\nItem ID: $(item_id)"