# Processes an item and gives the player another.
# Plays a sound after.

clear @s pumpkin_pie 1
function rmf:give_item/pumpkin_pie_slice {"player":"@s","count":4}
execute at @s run playsound rmf:item.cutting_board.use