# Processes an item and gives the player another.
# Plays a sound after.

clear @s cooked_chicken 1
function rmf:give_item/cooked_chicken_wing {"player":"@s","count":2}
execute at @s run playsound rmf:item.cutting_board.use