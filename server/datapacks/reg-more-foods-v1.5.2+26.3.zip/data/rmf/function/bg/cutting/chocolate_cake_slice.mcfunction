# Processes an item and gives the player another.
# Plays a sound after.

clear @s *[custom_data~{"item_id":"rmf:chocolate_cake"}] 1
function rmf:give_item/chocolate_cake_slice {"player":"@s","count":7}
execute at @s run playsound rmf:item.cutting_board.use