# A list of items that can be cut with the Cutting Board.
# Functions just like the other utility items, so the system used should be familiar.
# The list is pretty small, so not a whole lot is needed to make this work for addons. Just add an entry to the list.

# Run this function on a cooldown.
schedule function rmf:bg/item_cooldown 10t replace

# Bacon
execute if items entity @s weapon.offhand porkchop if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/bacon

# Chicken Wing
execute if items entity @s weapon.offhand chicken if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/chicken_wing

# Chicken Wing
execute if items entity @s weapon.offhand cooked_chicken if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/cooked_chicken_wing

# Pufferfish Tail
execute if items entity @s weapon.offhand pufferfish if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/pufferfish_tail

# Pumpkin Pie Slice
execute if items entity @s weapon.offhand pumpkin_pie if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/pumpkin_pie_slice

# Lettuce
execute if items entity @s weapon.offhand #leaves if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/lettuce

# Apple Pie Slice
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:apple_pie"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/apple_pie_slice

# Chocolate Cake
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:chocolate_cake"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/chocolate_cake_slice

# Cake (checks to see if it hasn't had any slices eaten from it yet)
execute if items entity @s weapon.offhand cake[!block_state] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:cutting_board"}] run return run function rmf:bg/cutting/cake_slice

# If none of the above entries matched, the player isn't able to do any of the steps. Thus, this function continues to this last command
title @s actionbar {"translate":"chat.rmf.use_item.empty_hand","color":"red"}