# Processes an item and gives the player another.
# Plays a sound after.

clear @s porkchop 1
function rmf:give_item/bacon {"player":"@s","count":2}
execute at @s run playsound rmf:item.cutting_board.use