# Processes an item and gives the player another.
# Plays a sound after.

clear @s *[custom_data~{"item_id":"rmf:apple_pie"}] 1
function rmf:give_item/apple_pie_slice {"player":"@s","count":2}
execute at @s run playsound rmf:item.cutting_board.use