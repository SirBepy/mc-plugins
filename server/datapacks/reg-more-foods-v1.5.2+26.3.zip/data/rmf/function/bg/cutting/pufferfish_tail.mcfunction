# Processes an item and gives the player another.
# Plays a sound after.

clear @s pufferfish 1
function rmf:give_item/pufferfish_tail {"player":"@s","count":1}
execute at @s run playsound rmf:item.cutting_board.use