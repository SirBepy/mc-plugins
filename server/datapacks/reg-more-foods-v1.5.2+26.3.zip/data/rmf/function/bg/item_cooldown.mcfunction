# This function runs on a schedule as long as the player has the advancement to trigger it.
# This cooldown can be altered by just changing the interval the scheule is run.
# The rmf:marshmallow_sandwich_craft advancement is also reset here, for the sake of convenience.

advancement revoke @a[advancements={rmf:bg/juice_item=true}] only rmf:bg/juice_item
advancement revoke @a[advancements={rmf:bg/shake_item=true}] only rmf:bg/shake_item
advancement revoke @a[advancements={rmf:bg/grind_item=true}] only rmf:bg/grind_item
advancement revoke @a[advancements={rmf:bg/roast_item=true}] only rmf:bg/roast_item
advancement revoke @a[advancements={rmf:bg/crate_item=true}] only rmf:bg/crate_item
advancement revoke @a[advancements={rmf:bg/mix_item=true}] only rmf:bg/mix_item
advancement revoke @a[advancements={rmf:bg/cut_item=true}] only rmf:bg/cut_item
advancement revoke @a[advancements={rmf:bg/marshmallow_sandwich_craft=true}] only rmf:bg/marshmallow_sandwich_craft