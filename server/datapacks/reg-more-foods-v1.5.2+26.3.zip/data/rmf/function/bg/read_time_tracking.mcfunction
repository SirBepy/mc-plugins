# This function figures out if Time Tracking is enabled, then displays it for the player.

execute if score rmf.config rmf.enableTimeTracking matches 1 run tellraw @s "Clock Time Tracking: Enabled"
execute if score rmf.config rmf.enableTimeTracking matches ..0 run tellraw @s "Clock Time Tracking: Disabled"