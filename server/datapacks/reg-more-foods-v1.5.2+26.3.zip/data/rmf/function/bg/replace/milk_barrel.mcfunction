# This function replaces vanilla items which appear to be RMF items with their original versions.
# This is because players may be confused when their tropical fish suddenly looks like Cheese after downloading the datapack.
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal item...
clear @s rabbit_foot[item_model="rabbit_foot",lore=[]] 1
give @s rabbit_foot[item_model="rmf:rabbit_foot",item_name={"translate":"item.rmf.rabbit_foot"}]