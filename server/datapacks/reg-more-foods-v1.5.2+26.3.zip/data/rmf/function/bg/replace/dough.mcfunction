# This function replaces Cottage Cheese with no data into Archer Pottery Sherds for players who have the item.
# This is because players may have Archer Pottery Sherds that will appear as Cottage Cheese after installing the datapack, and we don't want to confuse them!
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal Archer Pottery Sherd...
clear @s archer_pottery_sherd[item_model="archer_pottery_sherd",lore=[]] 1
give @s archer_pottery_sherd[item_model="rmf:archer_pottery_sherd",item_name={"translate":"item.rmf.archer_pottery_sherd"}]