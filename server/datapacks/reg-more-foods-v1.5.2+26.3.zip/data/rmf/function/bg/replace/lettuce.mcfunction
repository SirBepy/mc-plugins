# This function replaces Cottage Cheese with no data into Arms Up Pottery Sherds for players who have the item.
# This is because players may have Arms Up Pottery Sherds that will appear as Cottage Cheese after installing the datapack, and we don't want to confuse them!
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal Arms Up Pottery Sherd...
clear @s arms_up_pottery_sherd[item_model="arms_up_pottery_sherd",lore=[]] 1
give @s arms_up_pottery_sherd[item_model="rmf:arms_up_pottery_sherd",item_name={"translate":"item.rmf.arms_up_pottery_sherd"}]