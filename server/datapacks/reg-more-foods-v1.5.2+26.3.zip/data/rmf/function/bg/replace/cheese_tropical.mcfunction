# I changed the dummy item for Cheese so now I have to make this function.
# :(

clear @s minecraft:tropical_fish[custom_data~{"item_id":"rmf:cheese"}] 1
function rmf:give_item/cheese {"player":"@s","count":1}