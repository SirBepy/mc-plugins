# This function replaces vanilla items which appear to be RMF items with their original versions.
# This is because players may be confused when their tropical fish suddenly looks like Cheese after downloading the datapack.
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal item...
clear @s burn_pottery_sherd[item_model="burn_pottery_sherd",lore=[]] 1
give @s burn_pottery_sherd[item_model="rmf:burn_pottery_sherd",item_name={"translate":"item.rmf.burn_pottery_sherd"}]