# This function replaces vanilla items which appear to be RMF items with their original versions.
# This is because players may be confused when their tropical fish suddenly looks like Cheese after downloading the datapack.
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal item...

# Due to a very annoying edge case where a new item added has the same dummy item data as an old one, this function has the old item override the new item being replaced. Any players obtaining Phantom Membrane that needs to be updated will be given Coffee Beans, as it's existed longer than Herbs have. Until I think of a better way to do this, anyway.
clear @s phantom_membrane[item_model="phantom_membrane",lore=[]] 1
function rmf:fix/coffee_beans