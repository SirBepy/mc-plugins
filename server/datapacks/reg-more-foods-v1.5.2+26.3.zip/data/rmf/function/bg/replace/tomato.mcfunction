# This function replaces Beetroots with Tomatoes for players who have the item.
# Technically, they both look similar, but the unaffected version doesn't have the "Reg's More Foods" lore on it--without that lore, players might think Mojang added Tomatoes to Minecraft.
# It uses the tick function to detect the item, and runs this function.
clear @s beetroot[lore=[]] 1
function rmf:give_item/tomato {"player":"@s","count":1}