# I changed the dummy item for Vinegar so now I have to make this function.
# :(

clear @s minecraft:dragon_breath[custom_data~{"item_id":"rmf:vinegar"}] 1
function rmf:give_item/vinegar {"player":"@s","count":1}