# This function replaces vanilla items which appear to be RMF items with their original versions.
# This is because players may be confused when their tropical fish suddenly looks like Cheese after downloading the datapack.
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal item...
clear @s guster_banner_pattern[item_model="guster_banner_pattern",lore=[]] 1
give @s guster_banner_pattern[item_model="rmf:guster_banner_pattern",item_name={"translate":"item.rmf.guster_banner_pattern"}]