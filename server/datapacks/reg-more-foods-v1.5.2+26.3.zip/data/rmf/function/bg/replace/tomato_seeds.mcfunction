# This function replaces Beetroot Seeds with Tomato Seeds for players who have the item.
# Technically, they both look similar, but the unaffected version doesn't have the "Reg's More Foods" lore on it--without that lore, players might think Mojang added Tomatoes to Minecraft.
clear @s beetroot_seeds[lore=[]] 1
function rmf:give_item/tomato_seeds {"player":"@s","count":1}