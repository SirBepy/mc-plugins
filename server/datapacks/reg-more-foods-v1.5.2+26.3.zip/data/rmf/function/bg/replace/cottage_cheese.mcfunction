# This function replaces Cottage Cheese with no data into Angler Pottery Sherds for players who have the item.
# This is because players may have Angler Pottery Sherds that will appear as Cottage Cheese after installing the datapack, and we don't want to confuse them!
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal Angler Pottery Sherd...
clear @s angler_pottery_sherd[item_model="angler_pottery_sherd",lore=[]] 1
give @s angler_pottery_sherd[item_model="rmf:angler_pottery_sherd",item_name={"translate":"item.rmf.angler_pottery_sherd"}]