# This function replaces Bottles of Vinegar with no data into Dragon's Breath for players who have the item.
# This is because players may have Dragon's Breath that will appear as Bottles of Vinegar after installing the datapack, and we don't want to confuse them!
# It uses the tick function to detect the item, and runs this function.
# The only problem with this is that players who uninstall the datapack will have a broken texture instead of their normal Dragon's Breath...
clear @s danger_pottery_sherd[item_model="danger_pottery_sherd",lore=[]] 1
give @s danger_pottery_sherd[item_model="rmf:danger_pottery_sherd",item_name={"translate":"item.rmf.danger_pottery_sherd"}]