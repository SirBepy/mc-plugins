# This function figures out if Stonecutter Damage is enabled, then displays it for the player.

execute if score rmf.config rmf.stonecutterDamage matches 1 run tellraw @s "Stonecutter Damage: Enabled"
execute if score rmf.config rmf.stonecutterDamage matches ..0 run tellraw @s "Stonecutter Damage: Disabled"