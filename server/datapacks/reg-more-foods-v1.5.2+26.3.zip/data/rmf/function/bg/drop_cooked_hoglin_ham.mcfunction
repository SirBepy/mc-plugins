# This function controls what Hoglins drop when killed, specifically when a Hoglin is on fire.
# It's designed specifically for Cooked Ham, but can be edited to drop pretty much anything.

# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100

# Check for Ham
execute if score @s rmf.dropChance matches 0..50 run function rmf:give_item/cooked_ham {"player":"@s","count":1}

# Then, reset the score and remove the trigging advancement so we can check again later
scoreboard players set @s rmf.dropChance 0
advancement revoke @s only rmf:bg/killed_hoglin_fire