scoreboard players set rmf.config rmf.enableTimeTracking 0
title @a actionbar ""
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.doTimeTracking.disabled","color":"white"}]
playsound minecraft:block.note_block.didgeridoo