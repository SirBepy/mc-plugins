# Controls the recipe for the corresponding popcorn bag size. Also grants the "crafted_food" advancement if the player somehow hasn't gotten it yet.
# Remove the ingredient used, remove the empty popcorn bag in the player's inventory, then give the player the custom item.
# Oh yeah, also play a noise for the player putting popcorn in the bag.
#
# Because we're checking for a specific item in the offhand, it's safer to clear the offhand completely than risk the player accidentally using any popped corn in the inventory
item replace entity @s weapon.offhand with air
clear @s *[custom_data~{item_id:"rmf:popcorn_bag"}] 1
function rmf:give_item/small_popcorn_bag {"player":"@s","count":1}
playsound rmf:item.popcorn_bag.fill player @a ~ ~ ~
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food filled popcorn bag