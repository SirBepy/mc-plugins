# This function only activates when a player burns a Marshmallow on a Stick.
clear @s[gamemode=!creative] *[minecraft:custom_data~{item_id:"rmf:marshmallow_stick"}] 1
function rmf:give_item/burned_marshmallow_stick {"player":"@s","count":1}
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food roasted marshmallow stick
scoreboard players set @s rmf.roastingProgress 0
advancement revoke @s only rmf:bg/roast_item