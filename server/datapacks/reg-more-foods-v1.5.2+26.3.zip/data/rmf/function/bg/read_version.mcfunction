# This function grabs the current RMF version from the rmf:get_data config function, then displays it for the player.

$tellraw @s "RMF Version: $(version)"