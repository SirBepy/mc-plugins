scoreboard players set rmf.config rmf.enableTimeTracking 1
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.doTimeTracking.enabled","color":"white"}]
playsound minecraft:block.note_block.bell