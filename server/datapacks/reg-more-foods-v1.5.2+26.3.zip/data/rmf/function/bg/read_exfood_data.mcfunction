# This function grabs extra food data from the rmf:get_data config function, then displays it for the player.

$tellraw @s "\nCan Always Eat: $(can_always_eat)"