# This function controls what happens to the player when they eat a Double Glazed Apple Fritter.
# It reuses the rmf.dropChance score to run a 4/6 chance to tp the player 1000 blocks in the air.
execute store result score @s rmf.dropChance run random value 1..6
execute as @s at @s if score @s rmf.dropChance matches 1..4 run tp @s ~ ~1000 ~
execute if score @s rmf.dropChance matches 1..4 run effect give @s blindness 14 0 true
execute if score @s rmf.dropChance matches 1..4 run effect give @s invisibility 14 0 true
scoreboard players set @s rmf.dropChance 0
advancement revoke @s only rmf:bg/evil_fritter