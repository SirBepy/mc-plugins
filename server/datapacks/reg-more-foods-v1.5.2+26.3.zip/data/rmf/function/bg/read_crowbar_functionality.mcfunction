# This function figures out if Crowbar Functionality is enabled, then displays it for the player.

execute if score rmf.config rmf.itemCratesRequireCrowbar matches 1 run tellraw @s "Crowbar Functionality: Enabled"
execute if score rmf.config rmf.itemCratesRequireCrowbar matches ..0 run tellraw @s "Crowbar Functionality: Disabled"