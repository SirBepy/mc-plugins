# This function helps give any players who craft with a Powder Snow Bucket their bucket back.
give @s minecraft:bucket
advancement revoke @a only rmf:bg/bucket_refunder