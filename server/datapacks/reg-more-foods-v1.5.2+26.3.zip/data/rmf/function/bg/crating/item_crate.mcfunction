# This function controls what happens when an Item Crate stores another Item Crate.
# For safety reasons, there is not a function for an Item Crate storing an Item Crate with an Item Crate in it.
clear @s *[custom_data~{item_id:"rmf:item_crate"}] 10
function rmf:give_item/item_crate_crate {"player":"@s","count":1}
playsound rmf:item.item_crate.store_item player @a ~ ~ ~
advancement grant @s[advancements={rmf:isnt_that_crate=false}] only rmf:isnt_that_crate
advancement grant @s[advancements={rmf:dangerously_crateive=false}] only rmf:dangerously_crateive