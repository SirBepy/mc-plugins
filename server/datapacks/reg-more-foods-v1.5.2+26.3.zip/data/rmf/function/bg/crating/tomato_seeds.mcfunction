# This function controls what happens when an Item Crate stores an item.
# Basically, just clear 9 of the items the player was trying to store (and an Item Crate), give them an appropriate item crate, and play a noise. Also, give them an advancement for doing so if they don't already have it.
clear @s beetroot_seeds[!custom_data] 9
clear @s *[custom_data~{item_id:"rmf:item_crate"}] 1
function rmf:give_item/item_crate_tomato_seeds {"player":"@s","count":1}
playsound rmf:item.item_crate.store_item player @a ~ ~ ~
advancement grant @s[advancements={rmf:isnt_that_crate=false}] only rmf:isnt_that_crate