# Used to give the player a Marshmallow Sandwich when they use a Cracker item while holding a Roasted (or burned) Marshmallow on a Stick in their offhand.
# Uses the rmf:item_cooldown function to prevent players from spamming it.

schedule function rmf:bg/item_cooldown 10t append
clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:cracker"}] 2
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:roasted_marshmallow_stick"}] run clear @s[gamemode=!creative] *[minecraft:custom_data~{item_id:"rmf:roasted_marshmallow_stick"}] 1
execute if items entity @s weapon.offhand *[minecraft:custom_data~{item_id:"rmf:burned_marshmallow_stick"}] run clear @s[gamemode=!creative] *[minecraft:custom_data~{item_id:"rmf:burned_marshmallow_stick"}] 1
function rmf:give_item/marshmallow_sandwich {"player":"@s","count":1}
advancement grant @s only rmf:distinct_sandwich