# This function checks how many times the player has "beaten" Reg's More Foods.

title @s actionbar [{translate:"chat.rmf.gold_trophy.use1"},{score:{name:"@s",objective:"rmf.gourmandRewarded"},color:"gold"},{translate:"chat.rmf.gold_trophy.use2",color:"gold"}]
function rmf:give_item/gold_trophy {player:"@s",count:1}
advancement revoke @s only rmf:bg/gourmand_rewarded