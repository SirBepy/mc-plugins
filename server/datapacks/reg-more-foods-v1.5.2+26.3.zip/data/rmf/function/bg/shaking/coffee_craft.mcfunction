# This function is for crafting the recipe in the Shaker Cup. It triggers in the shake_item function.

# Remove the ingredient(s) from the player (if they aren't in creative) and play a sound
clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:coffee_grounds"}] 1
execute at @s run playsound minecraft:item.bundle.insert

# Remove the old shaker cup
clear @s *[custom_data~{item_id:"rmf:shaker_cup"},damage=2] 1

# Give the player a shaker cup with their recipe. The shaker cup needs to be shaken to finish it.
function rmf:give_item/shaker_cup_unshaken {"player":"@s","count":1,"contents":"coffee"}