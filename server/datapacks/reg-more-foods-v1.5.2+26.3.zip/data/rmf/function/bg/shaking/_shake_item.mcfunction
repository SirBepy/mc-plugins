# This file uses the same system as the Juicer to create drinks using the Shaker Cup. Despite my attempt at cleaning it up, it still looks like shit. Sorry.
# Custom addons can create new entries by adding them to the following "Check for" list (just copy one of my entries here and customize it for your custom item). Set the "return" function to your custom item, and then copy one of my entries again for THAT and edit it for your custom juice/item.
# You're smart, you'll figure it out. I believe in you!

# We first want to run a schedule every 10 ticks that checks if players are trying to use the Shaker Cup, and if they are, remove the checking advancement again. This allows the Shaker Cup to be held down and continously make things!
schedule function rmf:bg/item_cooldown 10t replace
# If everything above goes well, we can start checking for entry matches.

# The following commands check for "stage" crafting, to prepare for making drinks or foods
# Check for Water Bottles or Water Barrels (step 1 of drink crafting)
execute if items entity @s weapon.offhand minecraft:potion[minecraft:potion_contents=water] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=0] run return run function rmf:bg/shaking/base
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:water_barrel"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=0] run return run function rmf:bg/shaking/base
# Check for Snowballs (step 2 of drink crafting, requires step 1 of drink crafting)
execute if items entity @s weapon.offhand minecraft:snowball if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=3] run return run function rmf:bg/shaking/snow_base
# Check for Sugar (step 2 of coconut milk crafting, requires step 1 of drink crafting)
execute if items entity @s weapon.offhand minecraft:sugar if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=3] run return run function rmf:bg/shaking/sugar_base
# Check for an empty hand (if anything is inside the shaker cup when it's used with an empty hand, it will be emptied)
execute as @s if predicate rmf:empty_offhand if predicate rmf:is_crouching unless items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=0] run return run function rmf:bg/shaking/empty

# If the above stages have been checked and none match (the player is ready to start crafting), check for ingredient matches below

### Melon Smoothie Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:melon_mash"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/melon_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"melon_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"melon_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/melon_smoothie

### Peach Smoothie Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:peach_mash"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/peach_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"peach_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"peach_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/peach_smoothie

### Mango Smoothie Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:mango_mash"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/mango_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"mango_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"mango_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/mango_smoothie

### Banana Smoothie Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:banana_mash"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/banana_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"banana_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"banana_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/banana_smoothie

### Strawberry Smoothie Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:strawberry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:strawberry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/strawberry_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"strawberry_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"strawberry_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/strawberry_smoothie

### Blueberry Smoothie Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:blueberry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:blueberry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/blueberry_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"blueberry_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"blueberry_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/blueberry_smoothie

### Raspberry Smoothie Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:raspberry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:raspberry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/raspberry_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"raspberry_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"raspberry_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/raspberry_smoothie

### Blackberry Smoothie Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:blackberry_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:blackberry_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/blackberry_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"blackberry_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"blackberry_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/blackberry_smoothie

### Dragon Fruit Smoothie Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:dragon_fruit_mash"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/dragon_fruit_smoothie_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"dragon_fruit_smoothie"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"dragon_fruit_smoothie"}] run return run function rmf:bg/advancement/shaker_cup/dragon_fruit_smoothie

### Coconut Milk Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:coconut_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:coconut_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/coconut_milk_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:bucket if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"coconut_milk"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:bucket if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"coconut_milk"}] run return run function rmf:bg/advancement/shaker_cup/coconut_milk

### Coffee Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:coffee_grounds"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/coffee_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"coffee"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"coffee"}] run return run function rmf:bg/advancement/shaker_cup/coffee

### Vinegar Crafting ###

# If the player isn't holding at least 2 of the ingredient, don't move to the next step
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:apple_mash"},minecraft:count={max:1}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run title @s actionbar {"translate":"chat.rmf.shaker_cup.need_more_items","color":"red"}
# If the player has at least 2, put them in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:apple_mash"},minecraft:count={min:2}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/vinegar_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"vinegar"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"vinegar"}] run return run function rmf:bg/advancement/shaker_cup/vinegar

### Lemonade Crafting ###

# If the player has the necessary ingredient, put it in the shaker
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:lemon_juice"}] if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup"},minecraft:damage=2] run return run function rmf:bg/shaking/lemonade_craft
# If the player is ready to deposit what they crafted, make sure they have the proper container for it
# If they don't, let them know
execute unless items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"lemonade"}] run return run title @s actionbar {"translate": "chat.rmf.shaker_cup.need_container","color":"red"}
# If they do, let them
execute if items entity @s weapon.offhand minecraft:glass_bottle if items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup_filled","rmf_shakerContents":"lemonade"}] run return run function rmf:bg/advancement/shaker_cup/lemonade

# If none of the above entries matched, the player isn't able to do any of the steps. Thus, this function continues to this last command
# So, assuming the player isn't trying to finish a recipe by shaking the cup, tell the player they need to get something they can actually put in the Shaker Cup
execute unless items entity @s weapon.mainhand minecraft:firework_star[custom_data~{"item_id":"rmf:shaker_cup","rmf_canBeShaken":true}|custom_data~{"item_id":"rmf:shaker_cup_filled"}] run title @s actionbar {"translate": "chat.rmf.use_item.empty_hand","color":"red"}