# This function triggers if the shaker cup is used with an empty offhand.
# When this function is called, it replaces the player's shaker cup with a fresh one, clearing everything inside the old one.

# Clear the player's mainhand completely, then just give them a new shaker
item replace entity @s weapon.mainhand with air
function rmf:give_item/shaker_cup {"player":"@s","count":1}
# Play a sound so the player knows the item was emptied correctly
execute at @s run playsound rmf:item.shaker_cup.empty