# This function is the first step of all "shaking" recipes.
# When this function is called, it has to remove the water from the player's offhand and put it in the shaker cup.
# Since it can be activated from both water bottles and water barrels, we check for both here rather than making a second "base" function for the other use case.
#
# If the player is holding a Water Bottle, replace it with an empty one (if they aren't in creative)
execute if items entity @s weapon.offhand potion[minecraft:potion_contents=water] run give @s[gamemode=!creative] glass_bottle
execute if items entity @s weapon.offhand potion[minecraft:potion_contents=water] run clear @s[gamemode=!creative] potion[minecraft:potion_contents=water] 1
# If the player is holding a Water Barrel, remove one from their inventory (if they aren't in creative)
execute if items entity @s weapon.offhand minecraft:flower_banner_pattern[custom_data~{item_id:"rmf:water_barrel"}] run clear @s[gamemode=!creative] flower_banner_pattern[custom_data~{item_id:"rmf:water_barrel"}] 1
# Play a sound so the player knows the item was inserted correctly
execute at @s run playsound minecraft:item.bottle.empty
# Update the Shaker Cup's durability to show the current crafting stage, and change the lore (for some horrid reason, the set_damage item modifier function only accepts decimal percentages??? so we have to set it to -0.3 to remove 1 durability from the shaker. obv this does not work for any other item that doesn't have durability of 4 why mojang why is it like this)
item modify entity @s weapon.mainhand [{type:"set_damage","damage":-0.9,"add":true},{type:"minecraft:set_lore",lore:[{"translate":"item.rmf.shaker_cup.contents","color":"white","italic":false},{"translate":"item.rmf.shaker_cup.contents_water","color":"aqua","italic":false}],mode:"insert"}]