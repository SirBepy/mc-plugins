# This function is the second step of all recipes that require snowballs as base ingredient, typically smoothies.
# When this function is called, it has to remove the snowball from the player's offhand and put it in the shaker cup.
#
# If the player is holding a Snowball, remove one from their inventory (if they aren't in creative)
execute if items entity @s weapon.offhand snowball run clear @s[gamemode=!creative] snowball 1
# Play a sound so the player knows the item was inserted correctly
execute at @s run playsound minecraft:item.bottle.empty
# Update the Shaker Cup's durability to show the current crafting stage, and change the lore for the item
item modify entity @s weapon.mainhand [{type:"set_damage","damage":0.2,"add":true},{type:"minecraft:set_lore",lore:[{"translate":"item.rmf.shaker_cup.contents_snowball","color":"aqua","italic":false}],mode:"insert",offset:2}]