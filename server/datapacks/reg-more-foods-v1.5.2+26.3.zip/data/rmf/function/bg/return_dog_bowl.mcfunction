# Returns a bowl when you feed Dog Food to a dog.

give @s bowl