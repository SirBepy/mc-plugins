# This function initiates the Uninstall procedure.
# Basically, it removes any scoreboards, recipes, and advancements added.
# However, it doesn't remove any items given or gained through crafting or anything, that way a player can re-enable the pack and they will be useful again.
# It also doesn't uninstall itself--it just makes it safe to remove it from the datapack folder or modpack.
# If you wish to uninstall Reg's More Foods, DON'T call this specific function directly! Use /function rmf:_config instead!

# Inform the player of the uninstall process.
tellraw @a [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.uninstall_1","color":"white"}]

# Remove the scoreboards...
scoreboard objectives remove rmf.daytime
scoreboard objectives remove rmf.enableTimeTracking
scoreboard objectives remove rmf.mined_cactus
scoreboard objectives remove rmf.ate_cake
scoreboard objectives remove rmf.roastingProgress
scoreboard objectives remove rmf.recycle_bones
scoreboard objectives remove rmf.mined_wheat
scoreboard objectives remove rmf.mined_beetroots
scoreboard objectives remove rmf.fryingProgress
scoreboard objectives remove rmf.dropChance
scoreboard objectives remove rmf.mined_grass
scoreboard objectives remove rmf.mined_oak_leaves
scoreboard objectives remove rmf.mined_acacia_leaves
scoreboard objectives remove rmf.mined_cherry_leaves
scoreboard objectives remove rmf.mined_jungle_leaves
scoreboard objectives remove rmf.mined_mangrove_leaves
scoreboard objectives remove rmf.mined_tall_grass
scoreboard objectives remove rmf.mined_dark_oak_leaves
scoreboard objectives remove rmf.mined_pale_oak_leaves
scoreboard objectives remove rmf.mined_birch_leaves
scoreboard objectives remove rmf.mined_bush
scoreboard objectives remove rmf.mined_fern
scoreboard objectives remove rmf.gourmandRewarded
scoreboard objectives remove rmf.creativePanProgress
scoreboard objectives remove rmf.version
scoreboard objectives remove rmf.worldLoaded

# Remove all recipes...
function rmf:bg/config/take_all_recipes

# Remove all advancements...
advancement revoke @a from rmf:root
advancement revoke @a from rmf:recipes/root

# Everything important's been removed, so let the player know they can safely delete the datapack from their world/modloader
tellraw @a ""
tellraw @a [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.uninstall_2","color":"white"}]