# This function resets ALL scoreboards set in the load function. Then, runs rmf:load.
# The difference between this function and the load function is that the load function only runs these commands once, when the data pack is first loaded.
# This function can be called to manually reset scoreboards, just in case something breaks.

scoreboard players set rmf.config rmf.enableTimeTracking 1
scoreboard players set rmf.config rmf.itemCratesRequireCrowbar 1
scoreboard players set rmf.config rmf.stonecutterDamage 1
scoreboard players reset rmf.config rmf.version
scoreboard players set rmf.config rmf.worldLoaded 0
scoreboard players set @a rmf.roastingProgress 0
scoreboard players set @a rmf.fryingProgress 0
scoreboard players set @a rmf.bakingProgress 0
scoreboard players set @a rmf.creativePanProgress 0

# Ok, now run the load function and let the player know everything's been reset
function rmf:load
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.resetAllScores.success","color":"white"}]