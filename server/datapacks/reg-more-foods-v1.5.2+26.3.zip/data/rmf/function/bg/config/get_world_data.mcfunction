# Gets and displays various world scores that RMF uses.
# Ignores rmf.worldLoaded because... I mean, it should always be "1" if things are working correctly.

execute store result storage rmf:version version int 1 run scoreboard players get rmf.config rmf.version
tellraw @s "RMF World Info:\n"
function rmf:bg/read_version with storage rmf:version
function rmf:bg/read_time_tracking
function rmf:bg/read_crowbar_functionality
function rmf:bg/read_stonecutter_damage