# Runs 3 functions to check the component data of the item the player is holding: One to check the nutrition and saturation values, the second to see if it can be eaten at any time, and the third to check how long it takes to consume the item. If the player isn't holding anything, it'll let them know.
# Note that vanilla items, while having food components, don't have readable ones. The components are baked into the item, thus the command can't read it. It won't throw an error but it also won't do anything.
# Used for debugging and making it easier to add items to the wiki, but I kept it in the pack for anyone else to use if they know the command. Any extra info specific to the item I usually look up myself (like how oranges can cure poison), but I use this function to grab the important stuff quickly.

execute if predicate rmf:empty_mainhand run tellraw @s {"text":"\nYou need to hold a food item to run this command!","color":"red"}
execute if items entity @s weapon.mainhand *[!minecraft:custom_data] run tellraw @s {"text":"\nYou need to hold an item with custom data to run this command!","color":"red"}
function rmf:bg/read_item_data with entity @s SelectedItem.components."minecraft:custom_data"
function rmf:bg/read_itemupdated_data with entity @s SelectedItem.components."minecraft:custom_data"
function rmf:bg/read_food_data with entity @s SelectedItem.components."minecraft:food"
function rmf:bg/read_exfood_data with entity @s SelectedItem.components."minecraft:food"
function rmf:bg/read_foodseconds_data with entity @s SelectedItem.components."minecraft:consumable"