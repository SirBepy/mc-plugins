execute if score rmf.config rmf.stonecutterDamage matches 1 run tellraw @s ""
execute if score rmf.config rmf.stonecutterDamage matches 1 run tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.stonecutterDamage.already_enabled","color":"red"}]
execute if score rmf.config rmf.stonecutterDamage matches 0 run function rmf:bg/stonecutterenable