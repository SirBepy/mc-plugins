execute if score rmf.config rmf.itemCratesRequireCrowbar matches 1 run tellraw @s ""
execute if score rmf.config rmf.itemCratesRequireCrowbar matches 1 run tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.itemCratesRequireCrowbar.already_enabled","color":"red"}]
execute if score rmf.config rmf.itemCratesRequireCrowbar matches 0 run function rmf:bg/crowbarenable