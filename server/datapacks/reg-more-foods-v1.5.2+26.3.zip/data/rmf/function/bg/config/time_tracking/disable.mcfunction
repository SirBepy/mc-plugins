execute if score rmf.config rmf.enableTimeTracking matches 0 run tellraw @s ""
execute if score rmf.config rmf.enableTimeTracking matches 0 run tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.doTimeTracking.already_disabled","color":"red"}]
execute if score rmf.config rmf.enableTimeTracking matches 1 run function rmf:bg/daydisable