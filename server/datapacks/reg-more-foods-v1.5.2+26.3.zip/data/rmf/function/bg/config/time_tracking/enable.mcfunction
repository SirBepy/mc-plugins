execute if score rmf.config rmf.enableTimeTracking matches 1 run tellraw @s ""
execute if score rmf.config rmf.enableTimeTracking matches 1 run tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.doTimeTracking.already_enabled","color":"red"}]
execute if score rmf.config rmf.enableTimeTracking matches 0 run function rmf:bg/dayenable