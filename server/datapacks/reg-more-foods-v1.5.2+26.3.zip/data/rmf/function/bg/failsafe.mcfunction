# This function is a failsafe. It runs as soon as the player connects to the world, so the following scores are automatically applied to them. These ones specifically are important enough to warrent doing this here.
# The setup/update function files also do this, but better to be safe than sorry right?

scoreboard players set @s rmf.fryingProgress 0
scoreboard players set @s rmf.bakingProgress 0
scoreboard players set @s rmf.creativePanProgress 0
scoreboard players set @a rmf.gourmandRewarded 0