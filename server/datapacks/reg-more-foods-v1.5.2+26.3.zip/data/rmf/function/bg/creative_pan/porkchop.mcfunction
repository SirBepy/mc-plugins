# This function is the "frying" recipe. If conditions are met when frying items, the following commands will be run.
# Each command is designed only for non-creative players--if a player is in creative mode, the ingredient will not be consumed.
#
clear @s[gamemode=!creative] porkchop 1
give @s cooked_porkchop
# Remember to reset their cooking score so this doesn't run forever!
scoreboard players set @s rmf.creativePanProgress 0
execute as @s run summon minecraft:experience_orb ~ ~ ~ {Value:1}