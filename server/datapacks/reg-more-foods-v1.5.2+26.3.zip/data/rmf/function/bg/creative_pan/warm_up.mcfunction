# This works like both pan types. But you know that by now, don't you?

# If the player is standing in front of a block that can heat the pan, start warming up the pan to cook
execute at @s[scores={rmf.creativePanProgress=..19}] if block ^ ^1 ^ #rmf:heats_creative_pan_if_lit[lit=true] run scoreboard players add @s rmf.creativePanProgress 2
execute at @s[scores={rmf.creativePanProgress=..19}] if block ^ ^1 ^ #rmf:heats_creative_pan_always run scoreboard players add @s rmf.creativePanProgress 2

# Play a sound when the player starts cooking (copy the sound from the Frying Pan because it sounds better)
execute as @s[predicate=rmf:creative_pan_cookable,scores={rmf.creativePanProgress=2}] at @s run playsound rmf:item.frying_pan.cook player @s ~ ~ ~ .5

# If the player is trying to cook something but isn't standing in front of something that can heat the Creative Pan, yell at them until they do
execute at @s unless block ^ ^1 ^ #rmf:can_heat_creative_pan run title @s actionbar {"translate":"chat.rmf.frying_pan.no_heat","color":"red"}

# If the player is trying to cook something but isn't holding something they can cook in the Creative Pan, yell at them until they do
execute unless predicate rmf:creative_pan_cookable run title @s actionbar {"translate":"chat.rmf.frying_pan.no_item","color":"red"}

# If the player has reached max creativePanProgress, send them to the creative pan recipes function to decide their fate (what item gets cooked). Then, schedule a checkfor function to make sure they're still trying to cook
execute if score @s rmf.creativePanProgress matches 100.. run function rmf:bg/creative_pan/_recipes
schedule function rmf:bg/creative_pan/checkfor 2t