# This function is the "frying" recipe. If conditions are met when frying items, the following commands will be run.
# Each command is designed only for non-creative players--if a player is in creative mode, the ingredient will not be consumed.
#
clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:popcorn_seeds"}] 1
function rmf:give_item/popped_corn {"player":"@s","count":1}
# Remember to reset their cooking score so this doesn't run forever! Oh, and give them an advancement too.
scoreboard players set @s rmf.creativePanProgress 0
advancement grant @s[advancements={rmf:crafted_food=false}] only rmf:crafted_food popped corn
execute as @s run summon minecraft:experience_orb ~ ~ ~ {Value:1}