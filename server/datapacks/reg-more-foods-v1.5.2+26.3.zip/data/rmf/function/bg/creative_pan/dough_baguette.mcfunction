# This function is the "baking" recipe. If conditions are met when baking items, the following commands will be run.
# Each command is designed only for non-creative players--if a player is in creative mode, the ingredient will not be consumed.

clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:shaped_dough"},custom_model_data={strings:["dough_shape:baguette"]}] 1
function rmf:give_item/baguette {"player":"@s","count":1}
# Remember to reset their cooking score so this doesn't run forever! Oh, and give them an advancement too.
scoreboard players set @s rmf.creativePanProgress 0
advancement grant @s only rmf:crafted_food baguette
execute as @s run summon minecraft:experience_orb ~ ~ ~ {Value:1}