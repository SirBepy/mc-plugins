# Copies functionality from both pan types, and thus can be cooked on anything they can be cooked on. It also does so 5 times quicker.
# If you're adding a heat source to one of those pans, add it here too!

# Lower the player's rmf.creativePanProgress score if they AREN'T trying to cook anything
execute as @a[scores={rmf.creativePanProgress=1..}] at @s unless block ^ ^1 ^ #rmf:can_heat_creative_pan run scoreboard players set @s rmf.creativePanProgress 0

# Campfire
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ campfire[lit=true] run scoreboard players add @s rmf.creativePanProgress 5
# Fire
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ fire run scoreboard players add @s rmf.creativePanProgress 5
# Furnace
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ furnace[lit=true] run scoreboard players add @s rmf.creativePanProgress 5
# Smoker
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ smoker[lit=true] run scoreboard players add @s rmf.creativePanProgress 5
# Soul Campfire
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ soul_campfire[lit=true] run scoreboard players add @s rmf.creativePanProgress 5
# Soul Fire
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ soul_fire run scoreboard players add @s rmf.creativePanProgress 5
# Magma Block
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ magma_block run scoreboard players add @s rmf.creativePanProgress 5
# Blast Furnace
execute as @a[predicate=rmf:creative_pan_cookable,advancements={rmf:bg/creative_panning_item=true},scores={rmf.creativePanProgress=20..99}] at @s if block ^ ^1 ^ blast_furnace[lit=true] run scoreboard players add @s rmf.creativePanProgress 5
