# The Creative Pan is a combination of the Frying and Baking Pan, so its recipe file has entries from both.
# Any overlapping entries have obviously been removed.
# If you want to add entries for either pan type, I highly suggest adding it to the Creative Pan as well.

# -- VANILLA ITEMS --
# Items whoses ingredients are vanilla, even if the result isn't
# Cooked Beef
execute if items entity @s weapon.offhand beef run return run function rmf:bg/creative_pan/beef
# Cooked Porkchop
execute if items entity @s weapon.offhand porkchop run return run function rmf:bg/creative_pan/porkchop
# Cooked Mutton
execute if items entity @s weapon.offhand mutton run return run function rmf:bg/creative_pan/mutton
# Cooked Rabbit
execute if items entity @s weapon.offhand rabbit run return run function rmf:bg/creative_pan/rabbit
# Cooked Chicken
execute if items entity @s weapon.offhand chicken run return run function rmf:bg/creative_pan/chicken
# Cooked Cod
execute if items entity @s weapon.offhand cod run return run function rmf:bg/creative_pan/cod
# Cooked Salmon
execute if items entity @s weapon.offhand salmon run return run function rmf:bg/creative_pan/salmon
# Fried Eggs 
execute if items entity @s weapon.offhand egg run return run function rmf:bg/creative_pan/egg
# Soft Boiled Eggs (the creative pan is freakin awesome and allows for creating soft boiled eggs)
execute if items entity @s weapon.offhand brown_egg run return run function rmf:bg/creative_pan/brown_egg
# Hard Boiled Eggs (the creative pan is freakin awesome and allows for creating hard boiled eggs)
execute if items entity @s weapon.offhand blue_egg run return run function rmf:bg/creative_pan/blue_egg
# Zombie Jerky (zombie jerky takes priority over leather when cooking here)
execute if items entity @s weapon.offhand rotten_flesh run return run function rmf:bg/creative_pan/rotten_flesh
# Roasted Carrot
execute if items entity @s weapon.offhand carrot run return run function rmf:bg/creative_pan/carrot
# Honeycomb Candy
execute if items entity @s weapon.offhand honeycomb run return run function rmf:bg/creative_pan/honeycomb
# Toast
execute if items entity @s weapon.offhand bread run return run function rmf:bg/creative_pan/bread
# Baked Potato
execute if items entity @s weapon.offhand potato run return run function rmf:bg/creative_pan/potato

# -- DATAPACK ITEMS --
# Items whoses ingredients aren't vanilla, even if their results are
# Cooked Pufferfish Tail
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:pufferfish_tail"}] run return run function rmf:bg/creative_pan/pufferfish_tail
# Corn on the Cob (Cooked Corn)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:corn"}] run return run function rmf:bg/creative_pan/corn
# Popped Corn
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:popcorn_seeds"}] run return run function rmf:bg/creative_pan/popcorn_seeds
# Cooked Ham
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:ham"}] run return run function rmf:bg/creative_pan/ham
# Cooked Bacon
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:bacon"}] run return run function rmf:bg/creative_pan/bacon
# Cooked Chicken Wing
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:chicken_wing"}] run return run function rmf:bg/creative_pan/chicken_wing
# Fried Tofu
execute if items entity @s weapon.offhand poisonous_potato run return run function rmf:bg/creative_pan/tofu
# Omelette
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:raw_omelette"}] run return run function rmf:bg/creative_pan/raw_omelette
# Sweet Berry Jam
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:uncooked_sweet_berry_jam"}] run return run function rmf:bg/creative_pan/sweet_berry_jam
# Glow Berry Jam
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:uncooked_glow_berry_jam"}] run return run function rmf:bg/creative_pan/glow_berry_jam
# Egg Roll
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:uncooked_egg_roll"}] run return run function rmf:bg/creative_pan/egg_roll
# Pancake
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:pancake_mix"}] run return run function rmf:bg/creative_pan/pancake
# Waffle
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:waffle_batter"}] run return run function rmf:bg/creative_pan/waffle
# Scrambled Eggs
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:raw_eggs"}] run return run function rmf:bg/creative_pan/scrambled_eggs
# Bread (from Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:dough"}] run return run function rmf:bg/creative_pan/dough
# Baguette (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:baguette"]}] run return run function rmf:bg/creative_pan/dough_baguette
# Pretzel (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:pretzel"]}] run return run function rmf:bg/creative_pan/dough_pretzel
# Croissant (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:croissant"]}] run return run function rmf:bg/creative_pan/dough_croissant
# Plain Muffin (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:muffin"]}] run return run function rmf:bg/creative_pan/dough_muffin
# Plain Donut (from Shaped Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:nut"]}] run return run function rmf:bg/creative_pan/dough_nut
# Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:cookie"]}] run return run function rmf:bg/creative_pan/dough_cookie
# Cocoa Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:cocoa_cookie"]}] run return run function rmf:bg/creative_pan/dough_cocoa_cookie
# Honey Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:honey_cookie"]}] run return run function rmf:bg/creative_pan/dough_honey_cookie
# Sweet Berry Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:berry_cookie"]}] run return run function rmf:bg/creative_pan/dough_berry_cookie
# Glow Berry Cookie (from Cookie Dough)
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:shaped_dough"},minecraft:custom_model_data={"strings":["dough_shape:glow_berry_cookie"]}] run return run function rmf:bg/creative_pan/dough_glow_berry_cookie
# Dragon Fruit Pie
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:dragon_pie_mix"}] run return run function rmf:bg/creative_pan/dragon_pie_mix
# Baked Beans
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:unbaked_beans"}] run return run function rmf:bg/creative_pan/unbaked_beans
# Fruitcake
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:unbaked_fruitcake"}] run return run function rmf:bg/creative_pan/unbaked_fruitcake
# Lemon Pie
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:lemon_pie_mix"}] run return run function rmf:bg/creative_pan/lemon_pie_mix
# Banana Bread
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:banana_dough"}] run return run function rmf:bg/creative_pan/banana_dough
# Seasoned Ribs
execute if items entity @s weapon.offhand *[minecraft:custom_data~{"item_id":"rmf:ribs"}] run return run function rmf:bg/creative_pan/cooked_ribs

# If for some horrid reason the player is able to run this function WITHOUT passing any of the entries here, just reset their creativePanProgress and hope this works itself out
scoreboard players set @s rmf.creativePanProgress 0