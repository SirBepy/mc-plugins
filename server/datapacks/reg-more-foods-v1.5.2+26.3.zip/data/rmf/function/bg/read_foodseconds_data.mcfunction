# This function grabs data from the rmf:get_data config function, then displays it for the player.

$tellraw @s "\nTime to eat (in seconds): $(consume_seconds)"