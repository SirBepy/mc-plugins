scoreboard players set rmf.config rmf.itemCratesRequireCrowbar 0
title @a actionbar ""
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.itemCratesRequireCrowbar.disabled","color":"white"}]
playsound minecraft:block.note_block.didgeridoo