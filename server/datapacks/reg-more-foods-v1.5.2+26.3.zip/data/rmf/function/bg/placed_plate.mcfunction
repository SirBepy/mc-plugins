# When a plate is placed in an item frame, play a sound.
execute at @s run playsound rmf:item.plate.use neutral
advancement revoke @s only rmf:bg/placed_plate