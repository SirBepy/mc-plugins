scoreboard players set rmf.config rmf.itemCratesRequireCrowbar 1
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.itemCratesRequireCrowbar.enabled","color":"white"}]
playsound minecraft:block.note_block.bell