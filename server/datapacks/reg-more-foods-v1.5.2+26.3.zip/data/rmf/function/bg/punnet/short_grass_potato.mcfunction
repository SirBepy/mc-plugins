# Functions identically to the other punnet functions, but checks specifically for one item to prevent multiple items from dropping at the same time, every time.

# Check for Wild Potatoes (These have a 1% chance to appear as long as the player isn't in a desert)
execute at @s if biome ~ ~ ~ #rmf:has_wild_crops if score @s rmf.dropChance matches 0..1 run function rmf:give_item/wild_potato {player:'@s',count:1}

# Reset scores (and advancement) after checking so we can check again later
scoreboard players set @s rmf.dropChance 0
scoreboard players set @s rmf.mined_grass 0
advancement revoke @s only rmf:bg/punnet/short_grass