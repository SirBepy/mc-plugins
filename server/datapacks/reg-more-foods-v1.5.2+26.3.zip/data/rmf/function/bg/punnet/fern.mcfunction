# This function uses an advancement which checks if players break a specific block.
# If the player has met all conditions to obtain items in this list, roll a chance for the player to obtain one of the fruits/berries in the block broken.
# In the case of this function specifically, it checks for both Short Grass and Ferns due to Taiga biomes having much more of the latter.

# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100

# Check for Taiga Beans
execute at @s if score @s rmf.dropChance matches 0..20 run function rmf:give_item/taiga_beans {"player":"@s","count":1}

# Reset scores (and advancement) after checking so we can check again later
scoreboard players set @s rmf.dropChance 0
scoreboard players set @s rmf.mined_fern 0
advancement revoke @s only rmf:bg/punnet/fern