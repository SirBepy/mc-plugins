# This function uses an advancement which checks if players break a specific block.
# If the player has met all conditions to obtain items in this list, roll a chance for the player to obtain one of the fruits/berries in the block broken.
#
# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100
# Check for Peaches
execute at @s if score @s rmf.dropChance matches 0..3 run function rmf:give_item/peach {"player":"@s","count":1}
# Reset scores (and advancement) after checking so we can check again later
scoreboard players set @s rmf.dropChance 0
scoreboard players set @s rmf.mined_cherry_leaves 0
advancement revoke @s only rmf:bg/punnet/cherry_leaves