# This function uses an advancement which checks if players break a specific block.
# If the player has met all conditions to obtain items in this list, roll a chance for the player to obtain one of the fruits/berries in the block broken.
# This specific file is an alternate version of the "oak_leaves" file, except it drops Oranges instead of Apples. Both files are activated when a player mines Oak Leaves with a Punnet in the offhand, so even if they miss the Apples drop, they might get the drop for Oranges. Regardless, both run their own drop chances.
# (This file doesn't need to include the section for resetting scores/advancements, since the oak_leaves file does that already)
#
# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100
# Check for Oranges 
execute at @s if score @s rmf.dropChance matches 0..5 run function rmf:give_item/orange {"player":"@s","count":1}