# This function uses an advancement which checks if players break a specific block an advancement to run this function, which checks for the type of biome the player is in.
# If the player is in a biome which has an entry here and conditions to obtain it are met, roll a chance for the player to obtain one of the fruits/berries in the block broken.
# Important note: the biome checked is for the location of the PLAYER, not the BLOCK broken. A player could be standing in a snowy biome while breaking grass from a plains, and get Blackberry drops instead.
#
# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100
# Check for Maize
execute at @s if biome ~ ~ ~ #rmf:has_strawberries if score @s rmf.dropChance matches 0..25 run function rmf:give_item/corn {player:'@s',count:1}
scoreboard players set @s rmf.dropChance 0
scoreboard players set @s rmf.mined_tall_grass 0
advancement revoke @s only rmf:bg/punnet/tall_grass