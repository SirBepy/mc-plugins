# This function uses an advancement which checks if players break a specific block.
# If the player has met all conditions to obtain items in this list, roll a chance for the player to obtain one of the fruits/berries in the block broken.

# First, activate set the drop chance for the player to a random number (out of 100%)
execute store result score @s rmf.dropChance run random value 0..100

# Check for Apples (this allows the player to gather extra apples from oak trees)
execute at @s if score @s rmf.dropChance matches 0..3 run give @s apple

# To save space (and skip having to make extra files), run the alternate oak_leaves file for dropping Oranges here. Even if this file doesn't drop an extra Apple, the Oranges file might drop an item so we want to run both anyway
function rmf:bg/punnet/oak_leaves_orange

# Reset scores (and advancement) after checking so we can check again later
scoreboard players set @s rmf.dropChance 0
scoreboard players set @s rmf.mined_oak_leaves 0
advancement revoke @s only rmf:bg/punnet/oak_leaves