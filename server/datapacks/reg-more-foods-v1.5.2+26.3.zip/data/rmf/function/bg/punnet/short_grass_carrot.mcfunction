# Functions identically to the other punnet functions, but checks specifically for one item to prevent multiple items from dropping at the same time, every time.

# Check for Wild Carrots (These have a 1% chance to appear as long as the player isn't in a desert)
execute at @s if biome ~ ~ ~ #rmf:has_wild_crops if score @s rmf.dropChance matches 0..1 run function rmf:give_item/wild_carrot {player:'@s',count:1}