# Functions identically to the other punnet functions, but checks specifically for Taiga Beans to prevent Blueberries and Taiga Beans from dropping at the same time, every time.

# Check for Taiga Beans
execute at @s if biome ~ ~ ~ #rmf:has_taiga_beans if score @s rmf.dropChance matches 0..12 run function rmf:give_item/taiga_beans {player:'@s',count:1}