scoreboard players set rmf.config rmf.stonecutterDamage 0
title @a actionbar ""
tellraw @s ""
tellraw @s [{"text":"[RMF Config]","color":"yellow"}," ",{"translate":"rmfcommands.stonecutterDamage.disabled","color":"white"}]
playsound minecraft:block.note_block.didgeridoo