# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
give @s minecraft:red_dye 4
clear @s[gamemode=!creative] minecraft:rose_bush 1
execute at @s run playsound rmf:item.mortar_and_pestle.use