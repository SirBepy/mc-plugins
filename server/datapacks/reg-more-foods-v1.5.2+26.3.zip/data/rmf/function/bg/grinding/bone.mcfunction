# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
# This particular function starts the advancement chain for detecting the Inequivalent Exchange advancement, so give them that.
give @s minecraft:bone_meal 6
clear @s[gamemode=!creative] bone 1
execute at @s run playsound rmf:item.mortar_and_pestle.use
advancement grant @s[advancements={rmf:inequivalent_exchange=false}] only rmf:inequivalent_exchange grinded bones