# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
function rmf:give_item/biomash {"player":"@s","count":3}
clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:biomass"}] 1
execute at @s run playsound rmf:item.mortar_and_pestle.use