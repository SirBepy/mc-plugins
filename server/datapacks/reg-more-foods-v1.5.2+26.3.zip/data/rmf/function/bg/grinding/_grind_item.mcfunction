# This file uses the same system as the Juicer to create items using the Mortar & Pestle.
# Custom addons can create new entries by adding them to the following "Check for" list (just copy one of my entries here and customize it for your custom item). Set the "return" function to your custom item, and then copy one of my entries again for THAT and edit it for your custom juice/item.
# You're smart, you'll figure it out. I believe in you!

# We first want to run a schedule every 10 ticks that checks if players are trying to use the item, and if they are, remove the checking advancement again. This allows the item to be held down and continously grind things!
schedule function rmf:bg/item_cooldown 10t replace
# If everything above goes well, we can start checking for entry matches.

# Allium
execute if items entity @s weapon.offhand allium run return run function rmf:bg/grinding/allium
# Apple
execute if items entity @s weapon.offhand apple run return run function rmf:bg/grinding/apple
# Azure Bluet
execute if items entity @s weapon.offhand azure_bluet run return run function rmf:bg/grinding/azure_bluet
# Blaze Rod
execute if items entity @s weapon.offhand blaze_rod run return run function rmf:bg/grinding/blaze_rod
# Blue Orchid
execute if items entity @s weapon.offhand blue_orchid run return run function rmf:bg/grinding/blue_orchid
# Bone Meal
execute if items entity @s weapon.offhand bone_meal run return run function rmf:bg/grinding/bone_meal
# Bone
execute if items entity @s weapon.offhand bone run return run function rmf:bg/grinding/bone
# Breeze Rod
execute if items entity @s weapon.offhand breeze_rod run return run function rmf:bg/grinding/breeze_rod
# Cactus Flower
execute if items entity @s weapon.offhand cactus_flower run return run function rmf:bg/grinding/cactus_flower
# Cocoa Beans
execute if items entity @s weapon.offhand cocoa_beans run return run function rmf:bg/grinding/cocoa_beans
# Cornflower
execute if items entity @s weapon.offhand cornflower run return run function rmf:bg/grinding/cornflower
# Dandelion
execute if items entity @s weapon.offhand dandelion run return run function rmf:bg/grinding/dandelion
# Glow Berries
execute if items entity @s weapon.offhand glow_berries run return run function rmf:bg/grinding/glow_berries
# Ink Sac
execute if items entity @s weapon.offhand ink_sac run return run function rmf:bg/grinding/ink_sac
# Lilac
execute if items entity @s weapon.offhand lilac run return run function rmf:bg/grinding/lilac
# Lily of the Valley
execute if items entity @s weapon.offhand lily_of_the_valley run return run function rmf:bg/grinding/lily_of_the_valley
# Melon Slice
execute if items entity @s weapon.offhand melon_slice run return run function rmf:bg/grinding/melon_slice
# Orange Tulip
execute if items entity @s weapon.offhand orange_tulip run return run function rmf:bg/grinding/orange_tulip
# Oxeye Daisy
execute if items entity @s weapon.offhand oxeye_daisy run return run function rmf:bg/grinding/oxeye_daisy
# Peony
execute if items entity @s weapon.offhand peony run return run function rmf:bg/grinding/peony
# Pink Petals
execute if items entity @s weapon.offhand pink_petals run return run function rmf:bg/grinding/pink_petals
# Pink Tulip
execute if items entity @s weapon.offhand pink_tulip run return run function rmf:bg/grinding/pink_tulip
# Pitcher Plant
execute if items entity @s weapon.offhand pitcher_plant run return run function rmf:bg/grinding/pitcher_plant
# Poppy
execute if items entity @s weapon.offhand poppy run return run function rmf:bg/grinding/poppy
# Red Tulip
execute if items entity @s weapon.offhand red_tulip run return run function rmf:bg/grinding/red_tulip
# Rose Bush
execute if items entity @s weapon.offhand rose_bush run return run function rmf:bg/grinding/rose_bush
# Sugar Cane
execute if items entity @s weapon.offhand sugar_cane run return run function rmf:bg/grinding/sugar_cane
# Sunflower
execute if items entity @s weapon.offhand sunflower run return run function rmf:bg/grinding/sunflower
# Sweet Berries
execute if items entity @s weapon.offhand sweet_berries run return run function rmf:bg/grinding/sweet_berries
# Torchflower
execute if items entity @s weapon.offhand torchflower run return run function rmf:bg/grinding/torchflower
# Wheat
execute if items entity @s weapon.offhand wheat run return run function rmf:bg/grinding/wheat
# White Tulip
execute if items entity @s weapon.offhand white_tulip run return run function rmf:bg/grinding/white_tulip
# Wither Rose
execute if items entity @s weapon.offhand wither_rose run return run function rmf:bg/grinding/wither_rose
# Banana
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:banana"}] run return run function rmf:bg/grinding/banana
# Blackberry
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:blackberry"}] run return run function rmf:bg/grinding/blackberry
# Blueberry
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:blueberry"}] run return run function rmf:bg/grinding/blueberry
# Coconut Half
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:coconut_half"}] run return run function rmf:bg/grinding/coconut_half
# Coconut
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:coconut"}] run return run function rmf:bg/grinding/coconut
# Corn (Maize)
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:corn"}] run return run function rmf:bg/grinding/corn
# Mango
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:mango"}] run return run function rmf:bg/grinding/mango
# Peach
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:peach"}] run return run function rmf:bg/grinding/peach
# Raspberry
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:raspberry"}] run return run function rmf:bg/grinding/raspberry
# Strawberry
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:strawberry"}] run return run function rmf:bg/grinding/strawberry
# Biomass
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:biomass"}] run return run function rmf:bg/grinding/biomass
# Dragon Fruit
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:dragon_fruit"}] run return run function rmf:bg/grinding/dragon_fruit
# Taiga Beans
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:taiga_beans"}] run return run function rmf:bg/grinding/taiga_beans
# Coffee Beans
execute if items entity @s weapon.offhand *[custom_data~{"item_id":"rmf:coffee_beans"}] run return run function rmf:bg/grinding/coffee_beans

# If none of the above entries matched, the player isn't able to do any of the steps. Thus, this function continues to this last command
# So, tell the player they need to get something they can actually grind in the Mortar & Pestle
title @s actionbar {"translate":"chat.rmf.use_item.empty_hand","color":"red"}