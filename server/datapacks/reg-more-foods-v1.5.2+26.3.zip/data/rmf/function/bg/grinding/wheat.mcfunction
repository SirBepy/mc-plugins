# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
function rmf:give_item/wheat_flour {"player":"@s","count":1}
clear @s[gamemode=!creative] wheat 1
execute at @s run playsound rmf:item.mortar_and_pestle.use