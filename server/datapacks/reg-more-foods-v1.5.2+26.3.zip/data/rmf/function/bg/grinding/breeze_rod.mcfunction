# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
give @s minecraft:wind_charge 6
clear @s[gamemode=!creative] minecraft:breeze_rod 1
execute at @s run playsound rmf:item.mortar_and_pestle.use