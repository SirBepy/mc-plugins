# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
give @s minecraft:yellow_dye 4
clear @s[gamemode=!creative] minecraft:sunflower 1
execute at @s run playsound rmf:item.mortar_and_pestle.use