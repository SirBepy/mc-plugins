# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
# This particular function technically crafts a food, so give the player the advancement for making a custom food.
function rmf:give_item/coconut_half {"player":"@s","count":2}
clear @s[gamemode=!creative] *[custom_data~{item_id:"rmf:coconut"}] 1
execute at @s run playsound rmf:item.mortar_and_pestle.use
advancement grant @s only rmf:crafted_food coconut chunk