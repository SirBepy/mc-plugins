# Controls what happens when the player grinds an item.
# Typically, gives the player an item, removes an item, and plays a sound.
give @s minecraft:light_gray_dye 2
clear @s[gamemode=!creative] minecraft:oxeye_daisy 1
execute at @s run playsound rmf:item.mortar_and_pestle.use